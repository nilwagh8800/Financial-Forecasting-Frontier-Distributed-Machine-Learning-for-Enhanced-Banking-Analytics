#!/usr/bin/env python
import sys

current_age = None
total_balance = 0
count = 0

for line in sys.stdin:
    # Parse the input from the mapper
    line = line.strip()
    age, balance = line.split('\t', 1)

    # Convert balance to float
    balance = float(balance)

    # Check if the age group has changed
    if current_age == age:
        total_balance += balance
        count += 1
    else:
        if current_age:
            # Output the average balance for the previous age group
            print(f'{current_age}\t{total_balance / count}')
        current_age = age
        total_balance = balance
        count = 1

# Output the average balance for the last age group
if current_age:
    print(f'{current_age}\t{total_balance / count}')
