#!/usr/bin/env python
import sys

current_outcome = None
total_duration = 0
count = 0

for line in sys.stdin:
    # Parse the input from the mapper
    line = line.strip()
    outcome, duration = line.split('\t', 1)

    # Convert duration to int
    duration = int(duration)

    # Check if the outcome has changed
    if current_outcome == outcome:
        total_duration += duration
        count += 1
    else:
        if current_outcome:
            # Output the average duration for the previous outcome
            print(f'{current_outcome}\t{total_duration / count}')
        current_outcome = outcome
        total_duration = duration
        count = 1

# Output the average duration for the last outcome
if current_outcome:
    print(f'{current_outcome}\t{total_duration / count}')
