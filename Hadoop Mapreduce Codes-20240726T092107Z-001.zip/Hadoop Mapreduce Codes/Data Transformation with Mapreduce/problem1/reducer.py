#!/usr/bin/env python
import sys

current_job_type = None
total_balance = 0
count = 0

for line in sys.stdin:
    # Parse the input from the mapper
    line = line.strip()
    job_type, balance = line.split('\t', 1)

    # Convert balance to float
    try:
        balance = float(balance)
    except ValueError:
        continue

    # Check if the job type has changed
    if current_job_type == job_type:
        total_balance += balance
        count += 1
    else:
        if current_job_type:
            # Output the average balance for the previous job type
            print(f'{current_job_type}\t{total_balance/count}')
        current_job_type = job_type
        total_balance = balance
        count = 1

# Output the average balance for the last job type
if current_job_type == job_type:
    print(f'{current_job_type}\t{total_balance/count}')
